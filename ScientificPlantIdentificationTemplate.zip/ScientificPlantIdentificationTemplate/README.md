# Scientific Plant Identification Template
The Alexa Skill *"Scientific Plant Identification"* has a list of flowers associated with their scientific name. The skill generates a random flower from its list and gives you the scientific name. The flower is generated randomly when you ask the skill for a "plant i.d." or a "plant name"
